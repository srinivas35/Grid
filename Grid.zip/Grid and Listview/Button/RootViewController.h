//
//  RootViewController.h
//  Button
//
//  Created by Sailaja Kamisetty on 21/03/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController{
    
    UISegmentedControl *segmentedControl;
    NSMutableArray *arrayOfData;
    NSMutableArray *arrayofImages;
}

@property(nonatomic,retain) UISegmentedControl *segmentedControl;
@property(nonatomic,retain) NSMutableArray *arrayOfData;
@property(nonatomic,retain) NSMutableArray *arrayofImages;

- (IBAction)didChangeSegmentControl:(UISegmentedControl *)control;

@end
