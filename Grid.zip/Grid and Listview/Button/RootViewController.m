//
//  RootViewController.m
//  Button
//
//  Created by Sailaja Kamisetty on 21/03/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "RootViewController.h"
#import "ListView.h"

@implementation RootViewController

@synthesize arrayofImages;
@synthesize segmentedControl;
@synthesize  arrayOfData;

- (id)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    if (self) {
        
        arrayOfData=[[NSMutableArray alloc]initWithObjects:@"apple1",@"apple2",@"apple",@"orange1",@"orange2",@"orange3",@"cycle1",@"cycle2",@"mango1",@"mango2", nil];
        
        arrayofImages=[[NSMutableArray alloc]initWithObjects:@"1.png",@"2.png",@"3.png",@"4.png",@"5.png",@"6.png",@"7.png",@"8.png",@"9.png",@"10.png", nil];
        
        segmentedControl = [[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"List",@"Grid",nil]];
        [segmentedControl setFrame:CGRectMake(150, 0, 120, 30)];
        [segmentedControl setSegmentedControlStyle:UISegmentedControlStyleBar];
        [segmentedControl addTarget:self action:@selector(didChangeSegmentControl:) forControlEvents:UIControlEventValueChanged];
        
        UIBarButtonItem *segment = [[UIBarButtonItem alloc] initWithCustomView:segmentedControl];
        self.navigationItem.rightBarButtonItem = segment;
        
        self.tableView.separatorColor=[UIColor clearColor];
        self.segmentedControl.selectedSegmentIndex =1;
        self.tableView.backgroundColor = [UIColor clearColor];
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

/*
 // Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations.
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
 */

// Customize the number of sections in the table view.

- (void)viewDidLoad
{
    [super viewDidLoad];
}

-(void) Listviewclass{
    
    ListView *list=[[ListView alloc]init];
    list.array1=self.arrayOfData;
    list.array=self.arrayofImages;
    self.segmentedControl.selectedSegmentIndex =1;
    [self.navigationController pushViewController:list animated:YES];
}

- (IBAction)didChangeSegmentControl:(UISegmentedControl *)control {
    
    switch (segmentedControl.selectedSegmentIndex) {
        case 0:
            [self Listviewclass];
            break;
        case 1:
            self.title=@"Grid view";
        default:
            break;
    }
}
        
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if(self.segmentedControl.selectedSegmentIndex==0){
        return [arrayOfData count];
    }
    else{
        return 1;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellID = @"CellID";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellID];
    if(cell == nil) {
        cell =  [[[UITableViewCell alloc] 
                  initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellID] autorelease];
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
        int n=[arrayofImages count];
        NSLog(@"arrrayo f data is %d",[arrayofImages count]);
       
        int i=0,l=0; 
        while(i<n){
            int y = 4 +l*74;
            int j=0;
            //Display the number of images 
            for(j=0; j<4;j++){
                
                if (i>=n) 
                    break;
                
                UIButton *button=[[UIButton alloc] init];
                [button setFrame:CGRectMake(18+80*j, y, 45, 45)];
                                
                UIImage *buttonImageNormal=[UIImage imageNamed:[arrayofImages objectAtIndex:i]];
                [button setBackgroundImage:buttonImageNormal	forState:UIControlStateNormal];
                [button setContentMode:UIViewContentModeCenter];
                
                UILabel *label = [[UILabel alloc] init ];
                [label setFrame:CGRectMake((80*j)+5, y+50, 80, 12)];
                label.text = [arrayOfData objectAtIndex:i];
                label.numberOfLines = 1;
				label.textColor = [UIColor blackColor];
				label.textAlignment = UITextAlignmentCenter;
                label.backgroundColor = [UIColor clearColor];
                label.font = [UIFont fontWithName:@"ArialMT" size:12]; 

                [cell.contentView addSubview:button];
                [cell.contentView addSubview:label];
                [button release];
                i++;
            }
            l = l+1;
        }
        return cell;
    }

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    /*
    DetailViewController *detailViewController = [[DetailViewController alloc] initWithNibName:@"Nib name" bundle:nil];
    // ...
    // Pass the selected object to the new view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
    [detailViewController release];
	*/
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload
{
    [super viewDidUnload];

    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}

- (void)dealloc
{
    [super dealloc];
}

@end
