//
//  ListView.h
//  Button
//
//  Created by Sailaja Kamisetty on 21/03/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ListView : UITableViewController {
    NSMutableArray *array;
    NSMutableArray *array1;
}

@property(nonatomic,retain) NSMutableArray *array;
@property(nonatomic,retain) NSMutableArray *array1;


@end
